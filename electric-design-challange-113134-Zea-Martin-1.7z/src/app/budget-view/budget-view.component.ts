import { Component } from '@angular/core';

@Component({
  selector: 'app-budget-view',
  standalone: true,
  imports: [],
  templateUrl: './budget-view.component.html',
  styleUrl: './budget-view.component.css',
})
export class BudgetViewComponent {
  // ADDITIONAL DOCS: same as BudgetListComponent
}
